# Shakeel Ahmed — Portfolio (Starter)

This is a starter **React + Vite + TailwindCSS** portfolio project prepared for Shakeel Ahmed.

## Quick start

1. Install dependencies:
```bash
npm install
```

2. Run dev server:
```bash
npm run dev
```

Open the URL shown in the console (usually http://localhost:5173).

## Supabase (optional)
- Create a `.env.local` file and add:
```
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```
- See `src/lib/supabaseClient.js` for usage example.

## Project structure
- `index.html`
- `src/` React source files
- `public/profile.jpg` placeholder (replace with your photo)

