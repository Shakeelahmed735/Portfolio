import React from 'react'

const events = [
  { year: '2022', title: 'Started learning HTML & CSS' },
  { year: '2023', title: 'Built first To-Do & Calculator projects' },
  { year: '2024', title: 'Learned JavaScript and API integration' },
  { year: '2025', title: 'Completed Frontend Virtual Internship' }
]

export default function Journey(){
  return (
    <section id="journey" className="mt-10 bg-white rounded p-6 shadow">
      <h2 className="text-2xl font-semibold mb-4">My Web Development Journey</h2>
      <div className="space-y-4">
        {events.map(e => (
          <div key={e.year} className="flex items-start gap-4">
            <div className="w-20 text-blue-600 font-bold">{e.year}</div>
            <div>
              <div className="font-semibold">{e.title}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}