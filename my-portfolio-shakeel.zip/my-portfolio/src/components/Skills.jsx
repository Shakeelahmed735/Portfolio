import React from 'react'

const skills = [
  {name: 'HTML5'},
  {name: 'CSS3'},
  {name: 'JavaScript'},
  {name: 'Responsive Design'},
  {name: 'Git & GitHub'},
  {name: 'Problem Solving'}
]

export default function Skills(){
  return (
    <section id="skills" className="mt-10">
      <h2 className="text-2xl font-semibold mb-4 text-white">Skills</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {skills.map(s => (
          <div key={s.name} className="bg-white/90 rounded p-4 shadow">
            <div className="font-semibold">{s.name}</div>
            <div className="text-sm text-gray-600 mt-2">Experienced with {s.name} in building projects.</div>
          </div>
        ))}
      </div>
    </section>
  )
}