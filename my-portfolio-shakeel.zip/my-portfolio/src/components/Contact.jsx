import React, { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function Contact(){
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try{
      const { data, error } = await supabase.from('contacts').insert([{ name: form.name, email: form.email, message: form.message }])
      setLoading(false)
      if(error) throw error
      alert('Message sent! Thank you.')
      setForm({ name: '', email: '', message: '' })
    }catch(err){
      setLoading(false)
      alert('Error: ' + err.message)
    }
  }

  return (
    <section id="contact" className="mt-10 bg-white rounded p-6 shadow">
      <h2 className="text-2xl font-semibold mb-4">Contact</h2>
      <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-3 max-w-xl">
        <input name="name" placeholder="Your name" value={form.name} onChange={handleChange} required className="p-3 border rounded" />
        <input name="email" type="email" placeholder="Your email" value={form.email} onChange={handleChange} required className="p-3 border rounded" />
        <textarea name="message" placeholder="Message" value={form.message} onChange={handleChange} className="p-3 border rounded" />
        <button type="submit" disabled={loading} className="bg-blue-600 text-white px-4 py-2 rounded">{loading ? 'Sending...' : 'Send Message'}</button>
      </form>
      <div className="mt-6">
        <p className="font-semibold">Connect with me:</p>
        <div className="flex gap-3 mt-2">
          <a href="mailto:shakeel@example.com" className="text-blue-600">Email</a>
          <a href="https://github.com/shakeelahmed" target="_blank" rel="noreferrer" className="text-gray-600">GitHub</a>
          <a href="https://linkedin.com/in/shakeelahmed" target="_blank" rel="noreferrer" className="text-blue-600">LinkedIn</a>
        </div>
      </div>
    </section>
  )
}