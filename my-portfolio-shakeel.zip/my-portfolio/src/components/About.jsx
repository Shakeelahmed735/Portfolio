import React from 'react'

export default function About(){
  return (
    <section id="about" className="mt-12 bg-white rounded-lg p-6 shadow">
      <h2 className="text-2xl font-semibold mb-4">About Me</h2>
      <p className="text-gray-700">Hello! I'm <strong>Shakeel Ahmed</strong>, a passionate web developer from Matiari. I studied at USMS Bhit Shah and continued learning web technologies through online courses and hands-on projects. I focus on creating clean, accessible, and responsive websites.</p>
    </section>
  )
}