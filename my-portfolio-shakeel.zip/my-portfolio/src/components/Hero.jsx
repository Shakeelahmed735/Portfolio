import React from 'react'

export default function Hero(){
  return (
    <section id="home" className="hero-gradient rounded-lg mt-8 p-8 text-white">
      <div className="flex flex-col md:flex-row items-center gap-6">
        <img src="/profile.jpg" alt="Shakeel Ahmed" className="w-36 h-36 rounded-full shadow-2xl border-4 border-white" />
        <div>
          <h1 className="text-4xl font-extrabold">Shakeel Ahmed</h1>
          <p className="mt-2 text-lg">Web Developer — building responsive and user-friendly websites</p>
          <p className="mt-4 max-w-xl text-slate-100">I started my web development journey at USMS Bhit Shah and through self-learning and projects I build practical web apps using HTML, CSS, and JavaScript.</p>
          <div className="mt-6 flex gap-3">
            <a href="#projects" className="bg-white text-blue-600 px-4 py-2 rounded shadow">View Projects</a>
            <a href="#contact" className="border border-white px-4 py-2 rounded">Contact Me</a>
          </div>
        </div>
      </div>
    </section>
  )
}