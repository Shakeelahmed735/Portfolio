import React from 'react'

export default function Footer(){
  const year = new Date().getFullYear()
  return (
    <footer className="mt-12 py-6 text-center text-gray-700">
      <div className="container mx-auto px-4">
        <div className="font-semibold">Made with ❤️ by Shakeel Ahmed</div>
        <div className="text-sm mt-2">© {year} Shakeel Ahmed. All rights reserved.</div>
      </div>
    </footer>
  )
}