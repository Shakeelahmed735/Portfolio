import React from 'react'

export default function Header(){
  const scrollTo = (id) => {
    const el = document.getElementById(id)
    if(el) el.scrollIntoView({ behavior: 'smooth' })
  }
  return (
    <header className="py-4 bg-white/10 backdrop-blur sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-between px-4">
        <div className="text-white font-bold">Shakeel Ahmed</div>
        <nav className="space-x-4">
          <button onClick={() => scrollTo('home')} className="text-white hover:text-gray-200">Home</button>
          <button onClick={() => scrollTo('about')} className="text-white hover:text-gray-200">About</button>
          <button onClick={() => scrollTo('skills')} className="text-white hover:text-gray-200">Skills</button>
          <button onClick={() => scrollTo('projects')} className="text-white hover:text-gray-200">Projects</button>
          <button onClick={() => scrollTo('contact')} className="text-white hover:text-gray-200">Contact</button>
        </nav>
      </div>
    </header>
  )
}